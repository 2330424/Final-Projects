//
//  ProjectApp.swift
//  Project
//
//  Created by Pranay Kongalla on 2024-05-19.
//

import SwiftUI

@main
struct ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
