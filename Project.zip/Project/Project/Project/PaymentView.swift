import SwiftUI

struct PaymentView: View {
    @State private var cardNumber: String = ""
    @State private var expiryDate: String = ""
    @State private var cvv: String = ""
    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 20) {
                Text("Debit/Credit")
                    .font(.title2)
                    .padding(.bottom, 10)

                TextField("0000 0000 0000 0000", text: $cardNumber)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)

                TextField("MM/YYYY", text: $expiryDate)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)

                TextField("CVV", text: $cvv)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(5)

                Spacer()

                Button(action: {
                    print("Make Payment button tapped")
                    showAlert = true
                }) {
                    Text("Make Payment")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(5.0)
                }
            }
            .padding()
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Order Successfully Placed"),
                    message: nil,
                    dismissButton: .default(Text("OK"))
                )
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

struct PaymentView_Previews: PreviewProvider {
    static var previews: some View {
        PaymentView()
    }
}








