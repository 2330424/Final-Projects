import SwiftUI

struct RegistrationView: View {
    @State private var name: String = ""
    @State private var username: String = ""
    @State private var mobileNumber: String = ""
    @State private var email: String = ""
    @State private var address: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var showAlert: Bool = false
    @State private var alertTitle: String = ""
    @State private var alertMessage: String = ""

    var body: some View {
        VStack {
            TextField("Name", text: $name)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)
            
            TextField("Username", text: $username)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            TextField("Mobile Number", text: $mobileNumber)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            TextField("E-Mail ID", text: $email)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            TextField("Address", text: $address)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            SecureField("Password", text: $password)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            SecureField("Confirm Password", text: $confirmPassword)
                .padding()
                .background(Color(.white))
                .cornerRadius(5.0)
                .padding(.bottom, 20)

            Button(action: {
                if name.isEmpty || username.isEmpty ||
                    mobileNumber.isEmpty || email.isEmpty || address.isEmpty || password.isEmpty || confirmPassword.isEmpty {
                    alertTitle = "All fields Required"
                
                } else {
                    alertTitle = "User Successfully Registered"
                    alertMessage = "Welcome, \(name)!"
                }
                showAlert = true
            }) {
                Text("Register")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(5.0)
            }
        }
        .padding(.horizontal, 20)
        .navigationTitle("Register")
        .alert(isPresented: $showAlert) {
            Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

struct RegistrationView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationView()
    }
}





