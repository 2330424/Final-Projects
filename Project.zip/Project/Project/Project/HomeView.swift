import SwiftUI

struct HomeView: View {
    @State private var selectedSize: String = "All"
    @State private var selectedPrice: String = "All"
    @State private var selectedTShirts: [TShirtWithQuantity] = []

    let tshirts: [TShirt] = [
        TShirt(imageName: "tshirt1", price: 40, size: "S"),
        TShirt(imageName: "tshirt2", price: 20, size: "S"),
        TShirt(imageName: "tshirt3", price: 30, size: "S"),
        TShirt(imageName: "tshirt4", price: 30, size: "M"),
        TShirt(imageName: "tshirt5", price: 20, size: "M"),
        TShirt(imageName: "tshirt6", price: 30, size: "M"),
        TShirt(imageName: "tshirt7", price: 20, size: "L"),
        TShirt(imageName: "tshirt8", price: 30, size: "L")
    ]

    let columns = [
        GridItem(.flexible(minimum: 150)),
        GridItem(.flexible(minimum: 150))
    ]

    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Menu {
                    Picker("Select Size", selection: $selectedSize) {
                        Text("All").tag("All")
                        Text("S").tag("S")
                        Text("M").tag("M")
                        Text("L").tag("L")
                    }
                } label: {
                    Text("Size: \(selectedSize)")
                        .padding(5)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(5)
                }
                .padding(.bottom, 10)

                Menu {
                    Picker("Select Price", selection: $selectedPrice) {
                        Text("All").tag("All")
                        Text("$20").tag("20")
                        Text("$30").tag("30")
                        Text("$40").tag("40")
                    }
                } label: {
                    Text("Price: \(selectedPrice)")
                        .padding(5)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(5)
                }
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(filteredTShirts) { tshirt in
                            TShirtView(tshirt: tshirt.tshirt, quantity: quantityFor(tshirt: tshirt.tshirt)) { quantityChange in
                                updateQuantity(for: tshirt.tshirt, by: quantityChange)
                            }
                        }
                    }
                    .padding()
                }

                NavigationLink(destination: CartView(tshirtsWithQuantity: $selectedTShirts)) {
                    Text("View Cart")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(5.0)
                }
                .padding()
            }
            .navigationBarTitle("Home", displayMode: .inline)
        }
    }
    var filteredTShirts: [TShirtWithQuantity] {
        tshirts.filter { tshirt in
            (selectedSize == "All" || tshirt.size == selectedSize) &&
            (selectedPrice == "All" || "\(tshirt.price)" == selectedPrice)
        }
        .map { tshirt in
            TShirtWithQuantity(tshirt: tshirt, quantity: quantityFor(tshirt: tshirt))
        }
    }

    func quantityFor(tshirt: TShirt) -> Int {
        selectedTShirts.first { $0.tshirt == tshirt }?.quantity ?? 0
    }
    func updateQuantity(for tshirt: TShirt, by amount: Int) {
        if let index = selectedTShirts.firstIndex(where: { $0.tshirt == tshirt }) {
            selectedTShirts[index].quantity += amount
            if selectedTShirts[index].quantity == 0 {
                selectedTShirts.remove(at: index)
            }
        } else if amount > 0 {
            selectedTShirts.append(TShirtWithQuantity(tshirt: tshirt, quantity: amount))
        }
    }
}

struct TShirt: Identifiable, Equatable {
    let id = UUID()
    let imageName: String
    let price: Int
    let size: String
}

struct TShirtWithQuantity: Identifiable {
    let id = UUID()
    let tshirt: TShirt
    var quantity: Int
}

struct TShirtView: View {
    let tshirt: TShirt
    let quantity: Int
    let onChangeQuantity: (Int) -> Void

    var body: some View {
        VStack {
            Image(tshirt.imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 150)
            Text("$\(tshirt.price)")
                .font(.headline)
            Text("Size: \(tshirt.size)")
                .font(.subheadline)

            HStack {
                Button("-") {
                    if quantity > 0 {
                        onChangeQuantity(-1)
                    }
                }
                Text("\(quantity)")
                Button("+") {
                    onChangeQuantity(1)
                }
            }
        }
    }
}






























