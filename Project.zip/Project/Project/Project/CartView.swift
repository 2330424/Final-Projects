import SwiftUI

struct CartView: View {
    @Binding var tshirtsWithQuantity: [TShirtWithQuantity]

    var total: Int {
        tshirtsWithQuantity.reduce(0) { $0 + ($1.tshirt.price * $1.quantity) }
    }

    var body: some View {
        VStack {
            Text("Total Price: $\(total)")
                .font(.largeTitle)
                .padding()

            List {
                ForEach(tshirtsWithQuantity) { tshirtWithQuantity in
                    HStack {
                        Image(tshirtWithQuantity.tshirt.imageName)
                            .resizable()
                            .frame(width: 50, height: 50)
                        VStack(alignment: .leading) {
                            Text("Size: \(tshirtWithQuantity.tshirt.size)")
                            Text("Price: $\(tshirtWithQuantity.tshirt.price)")
                            Text("Quantity: \(tshirtWithQuantity.quantity)")
                        }
                    }
                }
            }

            NavigationLink(destination: PaymentView()) {
                Text("Place Order")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(5.0)
            }
            .padding()
        }
        .navigationBarTitle("Cart", displayMode: .inline)
    }
}



